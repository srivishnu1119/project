package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.util.DBConnection;

public class MobileDAOImpl implements MobileDAO {

	@Override
	public String buyMobile(Customer customer,Mobiles mobile) throws Exception {
		
		
		String modelno=mobile.getModelNo();
		String mobilename=mobile.getMobilename();
		String id=null;
		
		Connection connection=null;
		try
		{
		connection=DBConnection.getConnection();
		int quant=0;
		Statement s1=connection.createStatement();
		ResultSet rS=s1.executeQuery("select quantity from mobiles where mobilename='"+mobilename+"' and modelno='"+modelno+"'");
			while(rS.next())
			{
			quant=rS.getInt(1);
			
			}
		
			if(quant>0)
			{
		PreparedStatement pS=connection.prepareStatement("insert into customer values(?,?,?,?,?,sysdate,id.nextval)");
		pS.setString(1,customer.getcName());
		pS.setString(2,customer.getEmail());
		pS.setString(3,customer.getPhoneNo());
		pS.setString(4,mobilename);
		pS.setString(5,modelno);
		pS.executeUpdate();
		
		ResultSet rs2=s1.executeQuery("select id.currval from customer");
		while(rs2.next())
		{
			id=rs2.getString(1);
		}
			
		Statement s=connection.createStatement();
		s.executeUpdate("update mobiles set quantity=quantity-1 where modelno='"+modelno+"' and mobilename='"+mobilename+"'");
		
		Statement s2=connection.createStatement();
		ResultSet rS1=s2.executeQuery("select quantity from mobiles where mobilename='"+mobilename+"' and modelno='"+modelno+"'");
				while(rS1.next())
				{
					quant=rS1.getInt(1);
				}
					if(quant==0)
					{
						Statement s3=connection.createStatement();
						s3.executeUpdate("delete from mobiles where mobilename='"+mobilename+"' and modelno='"+modelno+"'");
					}
					connection.close();
					}
					else
					{
						System.out.println("Stock Not Available");
					}
		
				}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		return id;
		
	}

	@Override
	public Mobiles searchMobile(String modelname,String modelno) throws Exception {
		// TODO Auto-generated method stub
		String modelName=modelname;
		String modelNo=modelno;
		
		Mobiles mobile=new Mobiles();
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		PreparedStatement s=connection.prepareStatement(QueryMapper.SEARCH_MOB);
		s.setString(1,modelNo);
		s.setString(2,modelName);
		ResultSet rS=s.executeQuery();
		
		while(rS.next())
		{
			
			String n=rS.getString(1);
			String n1=rS.getString(2);
			int a=rS.getInt(3);
			String b=rS.getString(4);
			mobile.setMobilename(n1);
			mobile.setModelNo(n);
			mobile.setoS(b);
			mobile.setQuantity(a);
		}
		connection.close();
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
		}
		return mobile;
	}

	@Override
	public List showStock() {
		List<Mobiles> li=new ArrayList<Mobiles>();
		
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		Statement s=connection.createStatement();
		ResultSet rS=s.executeQuery(QueryMapper.RETIRIVE_ALL);
		
		while(rS.next())
		{
			Mobiles mobile=new Mobiles();
			mobile.setModelNo(rS.getString(1));
			mobile.setMobilename(rS.getString(2));
			mobile.setQuantity(rS.getInt(3));
			mobile.setoS(rS.getString(4));
			
			li.add(mobile);	
			
		}
		connection.close();
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
		}

		return li;
	}

}

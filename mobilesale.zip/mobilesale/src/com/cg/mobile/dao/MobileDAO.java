package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;

public interface MobileDAO {

	public String buyMobile(Customer customer,Mobiles mobile) throws Exception;
	public Mobiles searchMobile(String modelname,String modelno) throws  Exception;
	public List showStock();
}

package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.dao.MobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.exception.MobileException;

public class MobileServiceImpl implements MobileService{
		MobileDAO mDAO=new MobileDAOImpl();
	@Override
	public String buyMobile(Customer customer,Mobiles mobile) throws Exception {
		System.out.println("In service");
		String x=mDAO.buyMobile(customer,mobile);
		return x;
	}

	public Mobiles searchMobile(String mobliename,String modelno) throws Exception {
		
		Mobiles mobile=new Mobiles();
		String name=mobliename;
		String no=modelno;
		mobile=mDAO.searchMobile(name,no);
		return mobile;
	}

	@Override
	public List showStock() {
		List<Mobiles> li=new ArrayList<Mobiles>();
		li=mDAO.showStock();
		
		return li;
	}
	
	
	public void validation(Customer customer) throws MobileException
	 {
		
		List validationerrors=new ArrayList();
		if(!isValidName(customer.getcName()))
		{
					validationerrors.add("Name should be minium of 3 characters");
		}
		if(!isValidEmail(customer.getEmail()))
		{
					validationerrors.add("Enter a valid email Id");
		}
		if(!isValidPhone(customer.getPhoneNo()))
		{
					validationerrors.add("Number should be only digits and 10 in length");
		}
		if(!validationerrors.isEmpty())
		{
					throw new MobileException(validationerrors+"\n");
		}
		
	}
	
	public void mobileValidation(Mobiles mobile) throws MobileException
	{
		
		List validationerror=new ArrayList();
		if(!isValidMobile(mobile.getMobilename()))
		{
			validationerror.add("mobile not available");
		}
		if(!validationerror.isEmpty())
		{
			throw new MobileException(validationerror+"\n");
		}
		
	}
	
	
	
	public boolean isValidName(String cname)
	{
		Pattern p=Pattern.compile("[A-Z][a-z]{3,}");
		Matcher m=p.matcher(cname);
		return m.matches();
	}
	public boolean isValidPhone(String phone)
	{
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(phone);
		return m.matches();
	}
	public boolean isValidEmail(String email)
	{
		Pattern p=Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$");
		Matcher m=p.matcher(email);
		return m.matches();
	}
	public boolean isValidMobile(String mobile)
	{
		String mobile1=mobile;
		
		if(mobile1.equals("samsung")||mobile1.equals("redmi")||mobile1.equals("iphone")||mobile1.equals("microsoft")||mobile1.equals("naaptol"))
		{
			
			return true;
		}
		else
		{
			return false;
		}
				
	}
	
}

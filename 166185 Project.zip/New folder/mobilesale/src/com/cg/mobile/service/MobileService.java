package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;

public interface MobileService {
		
	public String buyMobile(Customer customer,Mobiles mobile) throws Exception;
	public Mobiles searchMobile(String modelnaem,String modelno) throws Exception;
	public List showStock();
	
	
}

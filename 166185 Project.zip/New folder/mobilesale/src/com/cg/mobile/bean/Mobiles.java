package com.cg.mobile.bean;

public class Mobiles {
	
	public String mobilename;
	public String modelNo;
	public String oS;
	public int quantity;
	
	
	public String getMobilename() {
		return mobilename;
	}
	public void setMobilename(String mobilename) {
		this.mobilename = mobilename;
	}
	public String getModelNo() {
		return modelNo;
	}
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	public String getoS() {
		return oS;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setoS(String oS) {
		this.oS = oS;
	}
	
	
	
	@Override
	public String toString() {
		return "Mobiles [mobilename=" + mobilename + ", modelNo=" + modelNo + ", oS=" + oS + ", quantity=" + quantity + "] \n";
	}	
	

}

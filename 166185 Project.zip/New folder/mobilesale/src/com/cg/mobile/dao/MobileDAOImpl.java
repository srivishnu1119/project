package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.management.Query;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.util.DBConnection;

public class MobileDAOImpl implements MobileDAO {
	
	Logger logger=Logger.getLogger(MobileDAOImpl.class);
	public MobileDAOImpl() 
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	
	@Override
	public String buyMobile(Customer customer,Mobiles mobile) throws Exception {
		
		
		String modelno=mobile.getModelNo();
		String mobilename=mobile.getMobilename();
		String id=null;
		
		Connection connection=null;
		try
		{
		connection=DBConnection.getConnection();
		int quant=0;
		PreparedStatement s1=connection.prepareStatement(QueryMapper.SEARCH_QUANTITY);
		s1.setString(1,mobilename);
		s1.setString(2, modelno);
		ResultSet rS=s1.executeQuery();
			while(rS.next())
			{
			quant=rS.getInt(3);
			
			}
		
			if(quant>0)
			{
		PreparedStatement pS=connection.prepareStatement(QueryMapper.INSERT_CUST);
		pS.setString(1,customer.getcName());
		pS.setString(2,customer.getEmail());
		pS.setString(3,customer.getPhoneNo());
		pS.setString(4,mobilename);
		pS.setString(5,modelno);
		pS.executeUpdate();
		Statement ss1=connection.createStatement();
		ResultSet rs2=ss1.executeQuery(QueryMapper.SEQ_ID);
		while(rs2.next())
		{
			id=rs2.getString(1);
		}
			
		PreparedStatement s=connection.prepareStatement(QueryMapper.UPDATE_QUANTITY);
		s.setString(1,modelno);
		s.setString(2,mobilename);
		s.executeUpdate();
		
		PreparedStatement s2=connection.prepareStatement(QueryMapper.SEARCH_QUANTITY);
		s2.setString(1,mobilename);
		s2.setString(2,modelno);
		ResultSet rS1=s2.executeQuery();
				while(rS1.next())
				{
					quant=rS1.getInt(3);
				}
					if(quant==0)
					{
						PreparedStatement s3=connection.prepareStatement(QueryMapper.DELETE);
						s3.setString(1,mobilename);
						s3.setString(2,modelno);
						s3.executeUpdate();
						if(s3==null)
						{
							logger.info("not deleted");
						}
						else
						{
							logger.info("Deleted");
						}
					}
					connection.close();
					}
					else
					{
						System.out.println("Stock Not Available");
					}
			if(id==null)
			{
				logger.error("Not Inserted");
			}
			else
			{
				logger.info("Inserted Customer Table");
			}
		
				}
		catch(Exception e)
		{
		e.printStackTrace();
		logger.error("Check Exception");
		}
		return id;
		
	}

	@Override
	public Mobiles searchMobile(String modelname,String modelno) throws Exception {
		// TODO Auto-generated method stub
		String modelName=modelname;
		String modelNo=modelno;
		
		Mobiles mobile=new Mobiles();
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		PreparedStatement s=connection.prepareStatement(QueryMapper.SEARCH_MOB);
		s.setString(1,modelNo);
		s.setString(2,modelName);
		ResultSet rS=s.executeQuery();
		
		while(rS.next())
		{
			
			String n=rS.getString(1);
			String n1=rS.getString(2);
			int a=rS.getInt(3);
			String b=rS.getString(4);
			mobile.setMobilename(n1);
			mobile.setModelNo(n);
			mobile.setoS(b);
			mobile.setQuantity(a);
		}
		
		if(rS.next()==false)
		{
			logger.info("NOT Found");
		}
		else
		{
			logger.info("FOund Details");
		}
		connection.close();
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
			logger.error("Exception at search mobile");
		}
		return mobile;
	}

	@Override
	public List showStock() {
		List<Mobiles> li=new ArrayList<Mobiles>();
		
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		Statement s=connection.createStatement();
		ResultSet rS=s.executeQuery(QueryMapper.RETIRIVE_ALL);
		
		while(rS.next())
		{
			Mobiles mobile=new Mobiles();
			mobile.setModelNo(rS.getString(1));
			mobile.setMobilename(rS.getString(2));
			mobile.setQuantity(rS.getInt(3));
			mobile.setoS(rS.getString(4));
			
			li.add(mobile);	
			
		}
		connection.close();
		if(!li.isEmpty())
		{
			logger.info("List is empty");
		}
		else
		{
			logger.info("List Printed");
		}
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
			logger.error("Exception at retrive all");
		}

		return li;
	}

}

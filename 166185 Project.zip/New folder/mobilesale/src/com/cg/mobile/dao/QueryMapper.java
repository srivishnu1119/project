package com.cg.mobile.dao;

public interface QueryMapper {

	String RETIRIVE_ALL="select * from mobiles";
	String SEARCH_MOB="select * from mobiles where modelno=? and mobilename=?";
	String INSERT_CUST="insert into customer values(?,?,?,?,?,sysdate,id.nextval)";
	String SEARCH_QUANTITY="select * from mobiles where mobilename=? and modelno=?";
	String UPDATE_QUANTITY="update mobiles set quantity=quantity-1 where modelno=? and mobilename=?";
	String DELETE="delete from mobiles where mobilename=? and modelno=?";
	String SEQ_ID="select id.currval from customer";
}

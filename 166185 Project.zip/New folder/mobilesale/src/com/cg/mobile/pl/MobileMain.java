package com.cg.mobile.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.ws.ServiceMode;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.MobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileMain {
	static Scanner sc=new Scanner(System.in);
	static MobileService mobileService=null;
	static MobileServiceImpl mobileServiceimpl=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer=null;
		Mobiles mobiles=null;
		
		
		int option;
		while(true)
		{
			
			System.out.println("MOBILE SALE");
			System.out.println("____________");
			System.out.println("1.PURCHASE MOBILE");
			System.out.println("2.SEARCH MOBILE");
			System.out.println("3.VIEW MOBILES");
			System.out.println("4.EXIT");
			System.out.println("______________");
			System.out.println("ENTER YOUR OPTION");
			
			option=sc.nextInt();
			switch(option)
			{
			case 1:
				
				try {
					
					
					while(customer==null)
					{
					customer=customerDetails();
					}
					while(mobiles==null)
					{
					mobiles=MobileMain.mobiles();
					}
					mobileService=new MobileServiceImpl();
					try {
					String x=mobileService.buyMobile(customer,mobiles);
					System.out.println("Cust id :"+x);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				} 
				catch (MobileException e) {
					
				}
				
				
				break;
				
			case 2:
				mobileServiceimpl=new MobileServiceImpl();
				System.out.println("Mobile Name :");
				String mobileName=sc.next();
				System.out.println("Mobile No :");
				String modelNo=sc.next();
				try {
					System.out.println("mobiles "+mobileServiceimpl.searchMobile(mobileName,modelNo));
					
				}
				catch (Exception e) {
					System.out.println("No Mobile Found.");
				} 
				
				break;
				
			case 3:
				List<Mobiles> li=new ArrayList<Mobiles>();
				mobileServiceimpl=new MobileServiceImpl();
				li=mobileServiceimpl.showStock();
				System.out.println(li+"\n");
				
				break;
				
			case 4:
				
				System.exit(0);
				break;
				
			}
		}
		

	}
	
	public static Customer customerDetails() throws MobileException
	{
		Customer customer=new Customer();
		System.out.println("Enter Customer Details");
		System.out.println("Enter Customer Name :");
		//System.out.println("sssssssssssssssssss");
		customer.setcName(sc.next());
		System.out.println("xxxxxxxxxxxxxxxxxxx");
		
		System.out.println("Enter Phone Name :");
		customer.setPhoneNo(sc.next());
		
		System.out.println("Enter email Id :");
		customer.setEmail(sc.next());
		
		try
		{
			mobileServiceimpl=new MobileServiceImpl();
			mobileServiceimpl.validation(customer);
			return customer;
		}
		catch(Exception e)
		{
			System.out.println("\n enter valid Deatails \n"+"try agian");
		}
		return null;
	}
	public static Mobiles mobiles() throws MobileException
	{
		Mobiles mobile=new Mobiles();
		System.out.println("Enter Mobiles details you want :");
		System.out.println("Enter Mobile Name :");
		mobile.setMobilename(sc.next());
		
		System.out.println("Enter Model No");
		mobile.setModelNo(sc.next());
		try
		{
				mobileServiceimpl.mobileValidation(mobile);
				return mobile;
		}
		catch(MobileException e)
		{
			
		}
		return null;
	}

}

package com.cg.mobile.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.Assertions.*;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;

class MobileDAOImpl {
  
	
	
	
	
	@Test
	public void buyMobile(Customer customer2, Mobiles mobile2)  {
		MobileDAOImpl dao=new MobileDAOImpl();
		Customer customer=new Customer();
		Mobiles mobile=new Mobiles();
		customer.setcName("Sasdf");
		customer.setEmail("asdf@asdf.dfs");
		customer.setPhoneNo("9876543210");
		mobile.setMobilename("samsung");
		mobile.setModelNo("J5");
		
		assertEquals("1008",dao.buyMobile(customer,mobile));
	
		
		
	}
	

	
}

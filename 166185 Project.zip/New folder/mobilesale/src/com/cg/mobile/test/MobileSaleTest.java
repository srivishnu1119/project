package com.cg.mobile.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import com.cg.mobile.dao.*;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobiles;

class MobileSaleTest {

	@Test
	void testAddMobile() {
		MobileDAOImpl dao=new MobileDAOImpl();
		Customer customer=new Customer();
		Mobiles mobile=new Mobiles();
		customer.setcName("Sasdf");
		customer.setEmail("asdf@asdf.dfs");
		customer.setPhoneNo("9876543210");
		mobile.setMobilename("samsung");
		mobile.setModelNo("J5");
		assertEquals("1021","dao.buyMobile(customer, mobile)");
		
		
		
	}
//	@Test
//	public void testSearch() {
//		MobileDAOImpl dao=new MobileDAOImpl();
//		Customer customer=new Customer();
//		Mobiles mobile=new Mobiles();
//		dao
//	}

}
